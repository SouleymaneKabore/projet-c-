#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>

using namespace std;

// Définition de la structure Contact
struct Contact {
    string nom;
    string telephone;
    string email;
    string adresse;
};

// Classe GestionContacts
class GestionContacts {
private:
    vector<Contact> contacts;

    // Fonction utilitaire pour trouver un contact par nom
    int trouverContact(const string& nomRecherche) {
        for (size_t i = 0; i < contacts.size(); ++i) {
            if (contacts[i].nom == nomRecherche) {
                return i;
            }
        }
        return -1; // Contact non trouvé
    }

public:
    // Ajouter un nouveau contact
    void ajouterContact() {
        Contact c;
        cout << "Entrer le nom: ";
        cin.ignore();
        getline(cin, c.nom);
        cout << "Entrer le numéro de téléphone: ";
        getline(cin, c.telephone);
        cout << "Entrer l'email: ";
        getline(cin, c.email);
        cout << "Entrer l'adresse: ";
        getline(cin, c.adresse);
        contacts.push_back(c);
        cout << "Contact ajouté avec succès !" << endl;
    }

    // Modifier un contact existant
    void modifierContact() {
        string nomRecherche;
        cout << "Entrer le nom du contact à modifier: ";
        cin.ignore();
        getline(cin, nomRecherche);

        int index = trouverContact(nomRecherche);
        if (index != -1) {
            cout << "Modifier le numéro de téléphone: ";
            getline(cin, contacts[index].telephone);
            cout << "Modifier l'email: ";
            getline(cin, contacts[index].email);
            cout << "Modifier l'adresse: ";
            getline(cin, contacts[index].adresse);
            cout << "Contact modifié avec succès !" << endl;
        } else {
            cout << "Contact introuvable." << endl;
        }
    }

    // Supprimer un contact
    void supprimerContact() {
        string nomRecherche;
        cout << "Entrer le nom du contact à supprimer: ";
        cin.ignore();
        getline(cin, nomRecherche);

        int index = trouverContact(nomRecherche);
        if (index != -1) {
            contacts.erase(contacts.begin() + index);
            cout << "Contact supprimé avec succès !" << endl;
        } else {
            cout << "Contact introuvable." << endl;
        }
    }

    // Afficher tous les contacts
    void afficherContacts() {
        if (contacts.empty()) {
            cout << "Aucun contact à afficher." << endl;
            return;
        }
        for (const auto& c : contacts) {
            cout << "Nom: " << c.nom << endl;
            cout << "Téléphone: " << c.telephone << endl;
            cout << "Email: " << c.email << endl;
            cout << "Adresse: " << c.adresse << endl;
            cout << "-----------------------" << endl;
        }
    }

    // Sauvegarder les contacts dans un fichier
    void sauvegarderDansFichier(const string& fichier) {
        ofstream outFile(fichier);
        if (outFile.is_open()) {
            for (const auto& c : contacts) {
                outFile << c.nom << ";" << c.telephone << ";" << c.email << ";" << c.adresse << endl;
            }
            outFile.close();
            cout << "Contacts sauvegardés dans le fichier avec succès !" << endl;
        } else {
            cout << "Impossible d'ouvrir le fichier." << endl;
        }
    }

    // Charger les contacts depuis un fichier
    void chargerDepuisFichier(const string& fichier) {
        ifstream inFile(fichier);
        if (inFile.is_open()) {
            contacts.clear();
            string ligne;
            while (getline(inFile, ligne)) {
                Contact c;
                size_t pos = 0;
                pos = ligne.find(';');
                c.nom = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                pos = ligne.find(';');
                c.telephone = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                pos = ligne.find(';');
                c.email = ligne.substr(0, pos);
                ligne.erase(0, pos + 1);

                c.adresse = ligne;
                contacts.push_back(c);
            }
            inFile.close();
            cout << "Contacts chargés depuis le fichier avec succès !" << endl;
        } else {
            cout << "Impossible d'ouvrir le fichier." << endl;
        }
    }
};

// Fonction principale
int main() {
    GestionContacts gestionnaire;
    int choix;
    string fichier = "contacts.txt";

    do {
        cout << "\n--- Menu Gestion des Contacts ---" << endl;
        cout << "1. Ajouter un contact" << endl;
        cout << "2. Modifier un contact" << endl;
        cout << "3. Supprimer un contact" << endl;
        cout << "4. Afficher les contacts" << endl;
        cout << "5. Sauvegarder dans un fichier" << endl;
        cout << "6. Charger depuis un fichier" << endl;
        cout << "0. Quitter" << endl;
        cout << "Votre choix: ";
        cin >> choix;

        switch (choix) {
        case 1:
            gestionnaire.ajouterContact();
            break;
        case 2:
            gestionnaire.modifierContact();
            break;
        case 3:
            gestionnaire.supprimerContact();
            break;
        case 4:
            gestionnaire.afficherContacts();
            break;
        case 5:
            gestionnaire.sauvegarderDansFichier(fichier);
            break;
        case 6:
            gestionnaire.chargerDepuisFichier(fichier);
            break;
        case 0:
            cout << "a bientot !" << endl;
            break;
        default:
            cout << "Option invalide. Veuillez réessayer." << endl;
        }
    } while (choix != 0);

    return 0;
}
